<?php
include('connection.php');
$id = $_POST['id'];
$filedelete = $_POST['filedelete'];
$sql = "delete from records where id =".$id;
$result = mysqli_query($conn, $sql);
$status = unlink($filedelete); 
if($result && $status)
{
	echo "Data deleted";
}
else
{
	echo "Failed to delete";
}
?>