<?php
session_start();
include("connection.php");
if(isset($_POST['submit'])){ 
  $email = $_POST['email']; 
  $password = $_POST['pswrd']; 
 
 $sql = "SELECT id FROM users where email='".$email."' and password ='".$password."'";
 $result = mysqli_query($conn, $sql);
 $row = mysqli_fetch_assoc($result);
 if(mysqli_num_rows($result) ==1)
 {
    $_SESSION['id'] = $row['id'];
    header("Location: viewdata.php");
 } 
 else{
 	$_SESSION['error'] = "Username or password is incorrect";
 	header("location:index.php");
 }

}    
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style>
		

$body-bg: #c1bdba;
$form-bg: #13232f;
$white: #ffffff;

$main: #1ab188;
$main-light: lighten(#1ab188,5%);
$main-dark: darken(#1ab188,5%);

$gray-light: #a0b3b0;
$gray: #ddd;

$thin: 300;
$normal: 400;
$bold: 600;
$br: 4px;

*, *:before, *:after {
  box-sizing: border-box;
}

html {
	overflow-y: scroll; 
}

body {
  background:#c1bdba;
  font-family: 'Titillium Web', sans-serif;
}

a {
  text-decoration:none;
  color:#1ab188;
  transition:.5s ease;
  &:hover {
    color:$main-dark;
  }
}

.form {
  background:rgba(19, 35, 47, 0.9);
  padding: 40px;
  max-width:600px;
  margin:40px auto;
  border-radius:4px;
  box-shadow:0 4px 10px 4px rgba(#13232f,.3);
}

.tab-group {
  list-style:none;
  padding:0;
  margin:0 0 40px 0;
  &:after {
    content: "";
    display: table;
    clear: both;
  }
  li a {
    display:block;
    text-decoration:none;
    padding:15px;
    background:rgba(#a0b3b0,.25);
    color:#a0b3b0;
    font-size:20px;
    float:left;
    width:50%;
    text-align:center;
    cursor:pointer;
    transition:.5s ease;
    &:hover {
      background:$main-dark;
      color:#ffffff;
    }
  }
  .active a {
    background:#1ab188;
    color:#ffffff;
  }
}

.tab-content > div:last-child {
  display:none;
}


h1 {
  text-align:center;
  color:#ffffff;
  font-weight:300;
  margin:0 0 40px;
}

label {
  position:absolute;
  transform:translateY(6px);
  left:13px;
  color:rgba(255, 255, 255, 0.5);
  transition:all 0.25s ease;
  -webkit-backface-visibility: hidden;
  pointer-events: none;
  font-size:22px;
  .req {
  	margin:2px;
  	color:#1ab188;
  }
}

label.active {
  transform:translateY(50px);
  left:2px;
  font-size:14px;
  .req {
    opacity:0;
  }
}

label.highlight {
	color:#ffffff;
}

input, textarea {
  font-size:22px;
  display:block;
  width:100%;
  height:100%;
  padding:5px 10px;
  background:none;
  background-image:none;
  border:1px solid #a0b3b0;
  color:#ffffff;
  border-radius:0;
  transition:border-color .25s ease, box-shadow .25s ease;
  &:focus {
		outline:0;
		border-color:#1ab188;
  }
}

textarea {
  border:2px solid #a0b3b0;
  resize: vertical;
}

.field-wrap {
  position:relative;
  margin-bottom:40px;
}

.top-row {
  &:after {
    content: "";
    display: table;
    clear: both;
  }

  > div {
    float:left;
    width:48%;
    margin-right:4%;
    &:last-child { 
      margin:0;
    }
  }
}

.button {
  border:0;
  outline:none;
  border-radius:0;
  padding:8px 0;
  font-size:2rem;
  font-weight:600;
  text-transform:uppercase;
  letter-spacing:.1em;
  background:#1ab188;
  color:#ffffff;
  transition:all.5s ease;
  -webkit-appearance: none;
  &:hover, &:focus {
    background:$main-dark;
  }
}

.button-block {
  display:block;
  width:104%;
}

.forgot {
  margin-top:-20px;
  text-align:right;
}
#login{
  margin-right: 15px
}
.errormsg
{
   padding-bottom: 8px;
   color: white;

}
</style>
</head>
<body>

	<div class="form">
        
        <div id="login">   
        <h1>Welcome User</h1>
          <form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post">
          
            <div class="field-wrap">
            <label>
              Email Address<span class="req">*</span>
            </label>
            <input type="email" name= "email" required autocomplete="off"/>
          </div>
          
          <div class="field-wrap">
            <label>
              Password<span class="req">*</span>
            </label>
            <input type="password" name="pswrd" required autocomplete="off"/>
          </div>
          <div class="errormsg">
          	<?php
          	if (isset($_SESSION['error']))
            {
            echo $_SESSION['error'];
            //unset($_SESSION['error']);
            }
            ?>
          </div>
          
          <input type="submit" name ="submit" value="Log In" class="button button-block"/>
          
          </form>

        </div>
        
     
      
</div> <!-- /form -->

</body>
</html>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script type="text/javascript">
	$('.form').find('input, textarea').on('keyup blur focus', function (e) {
  
  var $this = $(this),
      label = $this.prev('label');

	  if (e.type === 'keyup') {
			if ($this.val() === '') {
          label.removeClass('active highlight');
        } else {
          label.addClass('active highlight');
        }
    } else if (e.type === 'blur') {
    	if( $this.val() === '' ) {
    		label.removeClass('active highlight'); 
			} else {
		    label.removeClass('highlight');   
			}   
    } else if (e.type === 'focus') {
      
      if( $this.val() === '' ) {
    		label.removeClass('highlight'); 
			} 
      else if( $this.val() !== '' ) {
		    label.addClass('highlight');
			}
    }

});

$('.tab a').on('click', function (e) {
  
  e.preventDefault();
  
  $(this).parent().addClass('active');
  $(this).parent().siblings().removeClass('active');
  
  target = $(this).attr('href');

  $('.tab-content > div').not(target).hide();
  
  $(target).fadeIn(600);
  
});
</script>